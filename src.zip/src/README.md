This is a rust server which contain gash terminal which is implement by myself.
1. It support serving dynamic html file which is marked as shtml.
2. Using safe synchronization mechanism.
3. Caching files in size between 1M~100M
4. Execute small task directly.
5. LRU for caching updating
6. Keep cache updated
7. schedule according to file size.
